
var dbName = 'log';
var _cloudant;
var _db;

function getCloudant(){
	if( !_cloudant ) {
		var vcapServices = JSON.parse(process.env.VCAP_SERVICES);
		if(vcapServices.cloudantNoSQLDB) {
			var dbUrl = vcapServices.cloudantNoSQLDB[0].credentials.url;
			_cloudant = require('cloudant')(dbUrl);
			return _cloudant;
		} else {
			throw new Error("No DB Service");
		}
	} else {
		return _cloudant;
	}
}

function getDb(){
	if( !_db ) {
		var cloudant = getCloudant();
		_db = cloudant.use(dbName);
	}
	return _db;
}

exports.info = function(callback){
	var cloudant = getCloudant();
	cloudant.db.get('log', function(err,body){
		callback(body);
	});

}

exports.metaData = function(callback){
	var dateFormat = require('dateformat');
	var metaData = { hosts: [] };
	var db = getDb();
			  
	  var recentCriteria = {
				"selector": {
					"time": {
						"$ne": "0"  
					}
				},
				"fields": [ "time" ],
				"sort": [
					    {
					      "time:string": "desc"
					    }
					  ],
				"limit": 1
		};
	  
	  var firstCriteria = {
				"selector": {
					"time": {
						"$ne": "0"  
					}
				},
				"fields": [ "time" ],
				"sort": [
					    {
					      "time:string": "asc"
					    }
					  ],
				"limit": 1
		};

		db.find(recentCriteria, function(err, result) {
			if( !err && result.docs ) {
				if( result.docs.length>0 ) {
					metaData.recent = dateFormat(result.docs[0].time, "yyyy-mm-dd HH:MM:ss");
				}
				
				db.find(firstCriteria, function(er, result) {
					if( !er ) {
						if( result.docs.length>0 ) {
							metaData.first = dateFormat(result.docs[0].time, "yyyy-mm-dd HH:MM:ss");
						}
						
						db.view('hosts', 'hosts', { "reduce": true, "group": true}, function(e, body) {
							if( !e ) {
								for(var i=0; i<body.rows.length; i++){
									var row = body.rows[i];
									if( row.key ) {
										metaData.hosts.push(row.key);
									}
								}
							} 
							
							  callback(metaData);
						});
					} else {
						 callback(metaData);
					}
				});
			} else {
				  callback({});
			}
		});
}

exports.buildDb = function buildDb(callback) {
	console.log('DB Utils - Building database');
	var cloudant = getCloudant();
	cloudant.db.create(dbName, function (err) {
		console.log('DB Utils - Database created');
		if (err && 'file_exists' !== err.error ) { 
			console.error('DB Utils - could not create db ', err);
			throw err;
		} 
		// create index - for now we'll index everything
		var db = cloudant.db.use(dbName);
		var all = { type:'text', index:{}};
		db.index(all, function(er, response) {
		  if (er) {
		    throw er;
		  }
			// create view for hosts
			var view = {
					  "views": {
					    "hosts": {
					      "map": "function (doc) {\n  emit(doc.host, 1);\n}",
					      "reduce": "_count"
					    }
					  },
					  "language": "javascript"
					};
			db.insert(view, '_design/hosts', function(err, body) {
				if( err && 'conflict' !== err.error ) console.error(err);
				callback();
			});
		});
	});
};

exports.initDb = function initDb(callback) {
	var cloudant = getCloudant();
	console.log('DB Utils - Destroying db');
	cloudant.db.destroy(dbName, function(err) {
		if( err ) console.log(err);
		exports.buildDb(callback);
	});
};


exports.addLogRecord = function addItem(req, callback) {
	// no need for a callback since this is async operation
	var syslogParser = require('glossy').Parse; 
	var logMsg = syslogParser.parse(req.body);
	var db = getDb();
	
	console.log('RAW: ' + req.body);
	console.log('PARSED: ', logMsg );
	
	var record = {	};
	record.time = logMsg.time;
	record.facility = logMsg.facility;
	record.severity = logMsg.severity;
	record.pid = logMsg.pid;
	record.message = logMsg.message;
	
	if( record.pid.startsWith("[RTR") ){
		// this is a router log - we can get a host name
		console.log("HOST " + JSON.stringify(record));
		var re = new RegExp('(.*?) - ');
		var hosts  = record.message.match(re);
		if( hosts && hosts.length>1) {
			record.host = hosts[1];
			console.log("HOST: " + record.host);
		}
	}
	
	db.insert(record, function(err, body) {
		console.error(err);
	});
}

exports.buildFilter = function( after, before, pid, severity, message, record, pageSize){
	var filter = {
		"selector": { 
			"_id": { "$ne": 0 }
		},
		"fields": [ "_id", "pid", "severity", "message", "time" ],
		"sort": [
			    {
			      "time:string": "asc"
			    }
			  ],
		"skip": record,
		"limit": pageSize
	};

	// add criteria
	if( pid && pid != 'all' ) {
		filter.selector.pid = {
				"$regex": pid  // ignore case
			}
	}
	
	if( severity && severity != 'all') {
		filter.selector.severity = severity;
	}
	
	if( message && message != '' ) {
		filter.selector.message = {
			"$regex": "(?i)" + message  // ignore case
		}
	}
	
	if( before ) {
		filter.selector.time = {
			"$lt": before 
		}
	}
	if( after ) {
		if( filter.selector.time ) {
			// append
			filter.selector.time["$gt"] = after;
		} else {
			filter.selector.time = {
					"$gt": after 
			}
		}
	}
	
	return filter;
}

exports.getAllMessages = function(skip, limit, callback){
	console.log('DB Utils - geting all messages');
	var db = getDb();
	var search = {
		  "selector": {
		    "time": {
		      "$ne": "0"
		    }
		  },
		  "fields": [
		    "_id",
		    "pid", "message", "severity", "time"
		  ],
		  "sort": [
		    {
		      "time:string": "asc"
		    }
		  ],
		  "skip": skip,
		  "limit": limit
		};

	db.find(search, function(er, result) {
		  if (er) {
		    throw er;
		  }
		  callback(er, result);
		});
}

exports.filterMessages = function( filter, callback ){
	var db = getDb();
	db.find(filter, function(err, result) {
		  callback(err, result);
	});
}




	