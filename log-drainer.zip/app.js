/*jshint node:true*/

var express = require('express');
var bodyParser = require('body-parser');
var session = require('express-session');
var syslogParser = require('glossy').Parse; 

var app = express();

// serve the files out of ./public as our main files
app.use(express.static(__dirname + '/public'));
app.use(bodyParser.text()); // logs come in as text content
app.use(bodyParser.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded
app.use(session({
    secret: 'mysecret',
    proxy: true,
    resave: true,
    saveUninitialized: true
}));

app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

var dbUtils = require('./dbUtils');

app.get('/home', function(req,res) {
	require('./routes/home.js').render(req,res);	
});

app.get('/view', function(req,res) {
	require('./routes/view.js').render(req,res);	
});

app.get('/meta', function(req,res) {
	dbUtils.metaData( function(metaData){
		res.json(metaData);
	});
});

app.post('/filter', function(req,res) {
	
	var before = "";
	var after = "";
	var pid = req.body.pid;
	if( pid ) {
		req.session.pid = pid;
	}
	var severity = req.body.severity;
	if( severity ) {
		req.session.severity = severity;
	}
	var message = req.body.message;
	if( message ) {
		req.session.message = message;
	} else {
		req.session.message = "";
	}
	var pageSize = 25;
	if( req.body.pageSize ) {
		pageSize = parseInt(req.body.pageSize);
	};
	req.session.pageSize = pageSize;
	
	if( req.body.after ) {
		after = new Date(Date.parse(req.body.after));
		req.session.after = after;
	} else {
		req.session.after = "";
	}
	if( req.body.before ) {
		before = new Date(Date.parse(req.body.before));
		req.session.before = before;
	} else {
		req.session.before = "";
	}

	
	var filter = dbUtils.buildFilter(after, before, pid, severity, message, 0, pageSize);
	req.session.filter = filter;
	require('./routes/view.js').render(req,res);
});

app.post('/log', function(req,res) {
	dbUtils.addLogRecord(req);
	res.sendStatus(200);  // immediately return, no need to wait for database to store
});


app.get('/', require('./routes/home.js').render );

app.get('/info', function(req,res){
	dbUtils.info(function(info){
		res.json(info);
	});
});


process.on('uncaughtException', function(err) {
    // handle the error safely
    console.log("****uncaught exception****\n" + err);
});


dbUtils.buildDb(function(){
	app.listen(app.get('port'), function() {
	  console.log("server starting on " + app.get('port'));
	});
	
});


