
var dbUtils = require('../dbUtils.js');

var entityMap = {
	    "&": "&amp;",
	    "<": "&lt;",
	    ">": "&gt;",
	    '"': '&quot;',
	    "'": '&#39;',
	    "/": '&#x2F;'
	  };

 function escapeHtml(string) {
    return String(string).replace(/[&<>"'\/]/g, function (s) {
      return entityMap[s];
    });
}
 
exports.render = function( request, response){
	
	if( request.session.filter ) {
		var filter = request.session.filter;
		var skip = 0;
		var limit = filter.limit;
		var nextLink = "#";
		var prevLink = "#";
		
		if( request.query.record ) {
			skip = parseInt(request.query.record);
			filter.skip = skip;
		} 

		if( request.query.pageSize ) {
			limit = parseInt(request.query.pageSize);
			filter.limit = limit;
		} 

		// before, after, pid, severity, message, record, pageSize, request, callback 
		dbUtils.filterMessages( filter, function( err, result ) {
			if( !err ) {
				if( result.docs.length>=limit ) {
					nextLink = "view?record=" + (skip + limit);
				}
				if( (skip - limit)>=0 ) {
					prevLink = "view?record=" + (skip - limit);
				}
				var dateFormat = require('dateformat');
				response.render('view', {records: result.docs, prevLink:prevLink , nextLink:nextLink, dateFormat:dateFormat } );
				
			} else {
				console.error(err);
				response.redirect('/');
			}
		} ); 

	}  else {
		response.redirect('/');
	}

};

