

exports.render = function( request, response){

	// pass in initial datetime for before and after filter fields
	var dateFormat = require('dateformat');
    var now = new Date();
    var initialDate = dateFormat(now, "yyyy-mm-dd'T'HH:MM:ss'Z'");
  
    // arguments for building home page
    var args = {initialDate:initialDate};
    if( request.session.after ) {
    	args.after = dateFormat(request.session.after, "yyyy-mm-dd HH:ss" );
    } else {
    	args.after = "";
    }
    if( request.session.before ) {
    	args.before = dateFormat(request.session.before, "yyyy-mm-dd HH:ss" );
    } else {
    	args.before = "";
    }
    if( request.session.severity ) {
    	args.severity =  request.session.severity;
    } else {
    	args.severity = "";
    }
    if( request.session.pid ) {
    	args.pid =  request.session.pid;
    } else {
    	args.pid = "";
    }
    if( request.session.message ) {
    	args.message = request.session.message;
    } else {
    	args.message = "";
    }
    args.pageSize = request.session.pageSize;
    
	response.render('home', args);

};

